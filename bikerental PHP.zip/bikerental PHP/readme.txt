Free Download Source Code "Online Bike Rental Management System"

FIRST Download

1.XAMPP

2."TEXT EDITOR" NOTEPAD++ OR SUBLIME TEXT 3 / ETC.

3"bikerental PHP"

4. Download the zip file/ download winrar

5. Extract the file and copy "bikerental PHP" folder

6.Paste inside root directory/ where you install xammp local disk C: drive D: drive E: paste: (for xampp/htdocs, 

7. Open PHPMyAdmin (http://localhost/phpmyadmin)

8. Create a database with name bikerental

6. Import bikerental.sql file(given inside the zip package in SQL file folder)

7.Run the script http://localhost/bikerental PHP

**LOGIN DETAILS** 

USERNAME : test@gmail.com

PASSWORD : Test@12345


For Admin Panel

Open Your browser put inside browser “http://localhost/bikerental/admin”

USERNAME : admin

PASSWORD : Test@12345

****** https:1sourcecodr.blogspot.com ******
Subcribe my You tube Channel **** 1 Source code ****